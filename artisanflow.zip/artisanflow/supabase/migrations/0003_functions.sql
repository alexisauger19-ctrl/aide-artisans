-- Opérations transactionnelles

-- Création d'une entreprise + membre admin + abonnement d'essai
create or replace function create_organization(org_name text) returns uuid
language plpgsql security definer set search_path = public as $$
declare org uuid;
begin
  if auth.uid() is null then raise exception 'Non authentifié'; end if;
  insert into organizations (name) values (org_name) returning id into org;
  insert into organization_members (organization_id, user_id, role) values (org, auth.uid(), 'admin');
  insert into subscriptions (organization_id, plan, status, trial_ends_at) values (org, 'starter', 'trialing', now() + interval '14 days');
  return org;
end $$;

-- Profil auto à l'inscription
create or replace function handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin insert into profiles (id, full_name) values (new.id, new.raw_user_meta_data->>'full_name'); return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

-- Émission d'une facture : numéro séquentiel sans trou, verrou de ligne
create or replace function issue_invoice(p_invoice uuid, p_due date) returns text
language plpgsql security definer set search_path = public as $$
declare inv invoices%rowtype; y int; n int; num text;
begin
  select * into inv from invoices where id = p_invoice for update;
  if not found or not is_member(inv.organization_id) then raise exception 'Facture introuvable'; end if;
  if inv.status <> 'brouillon' then raise exception 'Facture déjà émise'; end if;
  if not exists (select 1 from invoice_items where invoice_id = p_invoice) then raise exception 'Facture sans ligne'; end if;
  y := extract(year from current_date);
  if p_due < current_date then raise exception 'Échéance antérieure à la date d''émission'; end if;
  insert into invoice_counters (organization_id, year, last_value) values (inv.organization_id, y, 0) on conflict do nothing;
  update invoice_counters set last_value = last_value + 1 where organization_id = inv.organization_id and year = y returning last_value into n;
  num := 'F-' || y || '-' || lpad(n::text, 5, '0');
  update invoices set number = num, status = 'emise', issue_date = current_date, due_date = p_due, issued_at = now() where id = p_invoice;
  insert into audit_logs (organization_id, actor_id, action, entity_type, entity_id, metadata)
    values (inv.organization_id, auth.uid(), 'invoice.issued', 'invoice', p_invoice, jsonb_build_object('number', num));
  return num;
end $$;

-- Enregistrement d'un paiement (transaction + contrôle du solde)
create or replace function record_payment(p_invoice uuid, p_amount bigint, p_date date, p_method text, p_ref text) returns bigint
language plpgsql security definer set search_path = public as $$
declare inv invoices%rowtype; remaining bigint;
begin
  select * into inv from invoices where id = p_invoice for update;
  if not found or not is_member(inv.organization_id) then raise exception 'Facture introuvable'; end if;
  if inv.status in ('brouillon','annulee') then raise exception 'Facture non payable'; end if;
  remaining := inv.total_ttc - inv.paid_cents;
  if p_amount <= 0 or p_amount > remaining then raise exception 'Montant invalide (reste % centimes)', remaining; end if;
  insert into payments (organization_id, invoice_id, amount_cents, paid_on, method, reference, created_by)
    values (inv.organization_id, p_invoice, p_amount, p_date, p_method, p_ref, auth.uid());
  update invoices set paid_cents = paid_cents + p_amount,
    status = case when paid_cents + p_amount >= total_ttc then 'payee'::invoice_status else 'partiellement_payee'::invoice_status end
    where id = p_invoice;
  insert into audit_logs (organization_id, actor_id, action, entity_type, entity_id, metadata)
    values (inv.organization_id, auth.uid(), 'payment.recorded', 'invoice', p_invoice, jsonb_build_object('amount_cents', p_amount));
  return remaining - p_amount;
end $$;

-- Un devis accepté devient une facture brouillon (lignes copiées)
create or replace function quote_to_invoice(p_quote uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare q quotes%rowtype; new_id uuid;
begin
  select * into q from quotes where id = p_quote for update;
  if not found or not is_member(q.organization_id) then raise exception 'Devis introuvable'; end if;
  if q.status <> 'accepte' then raise exception 'Seul un devis accepté peut être facturé'; end if;
  insert into invoices (organization_id, client_id, quote_id, site_address, payment_terms, total_ht, total_vat, total_ttc)
    values (q.organization_id, q.client_id, q.id, q.site_address, q.payment_terms, q.total_ht, q.total_vat, q.total_ttc) returning id into new_id;
  insert into invoice_items (invoice_id, position, description, quantity, unit, unit_price_cents, discount_percent, vat_rate)
    select new_id, position, description, quantity, unit, unit_price_cents, discount_percent, vat_rate from quote_items where quote_id = p_quote;
  return new_id;
end $$;

-- Marquage des factures en retard (appelé par le cron serveur)
create or replace function flag_overdue_invoices() returns int language sql security definer set search_path = public as $$
  with u as (select id from invoices where status in ('emise','partiellement_payee') and due_date < current_date)
  select count(*)::int from u;
$$;
