-- ArtisanFlow — schéma initial (PostgreSQL / Supabase)
-- Montants en CENTIMES (bigint). Aucune suppression en cascade sur les données comptables.

create extension if not exists "pgcrypto";

create type member_role as enum ('admin', 'member');
create type client_kind as enum ('particulier', 'professionnel');
create type quote_status as enum ('brouillon', 'envoye', 'accepte', 'refuse', 'expire');
create type invoice_status as enum ('brouillon', 'emise', 'partiellement_payee', 'payee', 'annulee');
create type plan_code as enum ('starter', 'pro', 'business');

create or replace function set_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

-- Utilisateurs (profil lié à auth.users)
create table profiles (
  id uuid primary key references auth.users(id) on delete restrict,
  full_name text,
  is_platform_admin boolean not null default false, -- modifiable uniquement via service role (voir RLS)
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  logo_path text,
  address text, postal_code text, city text,
  phone text,
  siret text check (siret is null or siret ~ '^[0-9]{14}$'),
  vat_number text,
  vat_applicable boolean not null default true,
  legal_mentions text,
  payment_terms text default 'Paiement à 30 jours à réception de facture.',
  locale text not null default 'fr-FR',
  currency text not null default 'EUR',
  suspended_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table organization_members (
  organization_id uuid not null references organizations(id) on delete restrict,
  user_id uuid not null references auth.users(id) on delete restrict,
  role member_role not null default 'member',
  created_at timestamptz not null default now(),
  primary key (organization_id, user_id)
);
create index on organization_members (user_id);

create table clients (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete restrict,
  kind client_kind not null default 'particulier',
  name text not null,
  email text, phone text,
  address text, postal_code text, city text,
  siret text check (siret is null or siret ~ '^[0-9]{14}$'),
  notes text,
  reminders_opt_out boolean not null default false,
  archived_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on clients (organization_id, name);

create table quotes (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete restrict,
  client_id uuid not null references clients(id) on delete restrict,
  number text not null,
  version int not null default 1,
  parent_quote_id uuid references quotes(id) on delete restrict,
  status quote_status not null default 'brouillon',
  issue_date date not null default current_date,
  valid_until date,
  site_title text, site_address text,
  payment_terms text, special_terms text,
  total_ht bigint not null default 0, total_vat bigint not null default 0, total_ttc bigint not null default 0,
  archived_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id, number, version),
  check (valid_until is null or valid_until >= issue_date)
);
create index on quotes (organization_id, status);

create table quote_items (
  id uuid primary key default gen_random_uuid(),
  quote_id uuid not null references quotes(id) on delete restrict,
  position int not null default 0,
  description text not null,
  quantity numeric(12,3) not null check (quantity > 0),
  unit text not null default 'u',
  unit_price_cents bigint not null check (unit_price_cents >= 0),
  discount_percent numeric(5,2) not null default 0 check (discount_percent between 0 and 100),
  vat_rate numeric(5,2) not null check (vat_rate >= 0)
);
create index on quote_items (quote_id);

create table invoice_counters (
  organization_id uuid not null references organizations(id) on delete restrict,
  year int not null,
  last_value int not null default 0,
  primary key (organization_id, year)
);

create table invoices (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete restrict,
  client_id uuid not null references clients(id) on delete restrict,
  quote_id uuid references quotes(id) on delete restrict,
  number text,                       -- attribué à l'émission, séquentiel sans trou
  status invoice_status not null default 'brouillon',
  issue_date date, due_date date,
  site_address text,
  payment_terms text, legal_mentions text,
  total_ht bigint not null default 0, total_vat bigint not null default 0, total_ttc bigint not null default 0,
  paid_cents bigint not null default 0,
  issued_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id, number),
  check (due_date is null or issue_date is null or due_date >= issue_date),
  check (paid_cents >= 0 and paid_cents <= total_ttc or status = 'brouillon')
);
create index on invoices (organization_id, status, due_date);

create table invoice_items (
  id uuid primary key default gen_random_uuid(),
  invoice_id uuid not null references invoices(id) on delete restrict,
  position int not null default 0,
  description text not null,
  quantity numeric(12,3) not null check (quantity > 0),
  unit text not null default 'u',
  unit_price_cents bigint not null check (unit_price_cents >= 0),
  discount_percent numeric(5,2) not null default 0 check (discount_percent between 0 and 100),
  vat_rate numeric(5,2) not null check (vat_rate >= 0)
);
create index on invoice_items (invoice_id);

create table payments (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete restrict,
  invoice_id uuid not null references invoices(id) on delete restrict,
  amount_cents bigint not null check (amount_cents > 0),
  paid_on date not null default current_date,
  method text not null check (method in ('virement','cheque','especes','carte','autre')),
  reference text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create index on payments (invoice_id);

create table credit_notes (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete restrict,
  invoice_id uuid not null references invoices(id) on delete restrict,
  number text,
  reason text not null,
  total_ht bigint not null, total_vat bigint not null, total_ttc bigint not null,
  issued_at timestamptz,
  created_at timestamptz not null default now(),
  unique (organization_id, number)
);

create table appointments (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete restrict,
  client_id uuid references clients(id) on delete restrict,
  title text not null,
  address text, description text, notes text,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  timezone text not null default 'Europe/Paris',
  cancelled_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (ends_at > starts_at)
);
create index on appointments (organization_id, starts_at);

create table documents (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete restrict,
  client_id uuid references clients(id) on delete restrict,
  kind text not null check (kind in ('devis_pdf','facture_pdf','avoir','client','chantier','autre')),
  name text not null,
  storage_path text not null,      -- bucket privé
  mime_type text not null,
  size_bytes bigint not null check (size_bytes <= 10485760),
  created_at timestamptz not null default now()
);

create table email_templates (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete restrict,
  code text not null, subject text not null, body text not null,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique (organization_id, code)
);

create table email_logs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete restrict,
  to_email text not null, subject text not null,
  related_type text, related_id uuid,
  status text not null default 'en_attente' check (status in ('en_attente','envoye','erreur')),
  error text,
  sent_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table automation_rules (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete restrict,
  kind text not null check (kind in ('devis_sans_reponse','echeance_facture','facture_en_retard','rappel_rdv','tache_en_attente')),
  enabled boolean not null default false,          -- désactivé par défaut
  delay_days int not null default 7 check (delay_days between 0 and 365),
  max_repeats int not null default 2,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique (organization_id, kind)
);

create table automation_executions (
  id uuid primary key default gen_random_uuid(),
  rule_id uuid not null references automation_rules(id) on delete restrict,
  organization_id uuid not null references organizations(id) on delete restrict,
  target_type text, target_id uuid,
  status text not null check (status in ('ok','ignore','erreur')),
  message text,
  ran_at timestamptz not null default now()
);
create index on automation_executions (organization_id, ran_at desc);

create table plans (
  code plan_code primary key,
  name text not null,
  price_cents int not null,
  stripe_price_id text,
  ai_quota_monthly int not null default 0,
  max_members int not null default 1,
  features jsonb not null default '{}'
);
insert into plans (code, name, price_cents, ai_quota_monthly, max_members, features) values
 ('starter','Starter',1900,0,1,'{"relances":false,"agenda":false,"ia":false,"automations":false}'),
 ('pro','Pro',3900,100,1,'{"relances":true,"agenda":true,"ia":true,"automations":true}'),
 ('business','Business',7900,500,10,'{"relances":true,"agenda":true,"ia":true,"automations":true,"exports":true}');

create table subscriptions (
  organization_id uuid primary key references organizations(id) on delete restrict,
  plan plan_code not null references plans(code),
  status text not null default 'trialing',
  stripe_customer_id text, stripe_subscription_id text,
  trial_ends_at timestamptz, current_period_end timestamptz,
  ai_used_this_period int not null default 0,
  updated_at timestamptz not null default now()
);

create table notifications (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete restrict,
  user_id uuid references auth.users(id),
  title text not null, body text, link text,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table audit_logs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid references organizations(id) on delete restrict,
  actor_id uuid references auth.users(id),
  action text not null,
  entity_type text, entity_id uuid,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);
create index on audit_logs (organization_id, created_at desc);

-- Triggers updated_at
do $$ declare t text; begin
  foreach t in array array['profiles','organizations','clients','quotes','invoices','appointments','email_templates','automation_rules','subscriptions'] loop
    execute format('create trigger trg_%1$s_updated before update on %1$s for each row execute function set_updated_at()', t);
  end loop; end $$;
