-- Isolation stricte entre entreprises (Row Level Security)

create or replace function is_member(org uuid) returns boolean
language sql security definer stable set search_path = public as $$
  select exists (select 1 from organization_members where organization_id = org and user_id = auth.uid());
$$;

create or replace function is_org_admin(org uuid) returns boolean
language sql security definer stable set search_path = public as $$
  select exists (select 1 from organization_members where organization_id = org and user_id = auth.uid() and role = 'admin');
$$;

do $$ declare t text; begin
  foreach t in array array['clients','quotes','invoices','payments','credit_notes','appointments','documents','email_templates','email_logs','automation_rules','automation_executions','notifications'] loop
    execute format('alter table %I enable row level security', t);
    execute format('create policy "%1$s_select" on %1$I for select using (is_member(organization_id))', t);
    execute format('create policy "%1$s_insert" on %1$I for insert with check (is_member(organization_id))', t);
    execute format('create policy "%1$s_update" on %1$I for update using (is_member(organization_id)) with check (is_member(organization_id))', t);
  end loop; end $$;
-- Pas de policy DELETE : aucune suppression côté client (archivage uniquement).

-- Lignes : accès via le document parent
alter table quote_items enable row level security;
create policy quote_items_all on quote_items for all
  using (exists (select 1 from quotes q where q.id = quote_id and is_member(q.organization_id)))
  with check (exists (select 1 from quotes q where q.id = quote_id and q.status = 'brouillon' and is_member(q.organization_id)));
alter table invoice_items enable row level security;
create policy invoice_items_all on invoice_items for all
  using (exists (select 1 from invoices i where i.id = invoice_id and is_member(i.organization_id)))
  with check (exists (select 1 from invoices i where i.id = invoice_id and i.status = 'brouillon' and is_member(i.organization_id)));

alter table organizations enable row level security;
create policy org_select on organizations for select using (is_member(id));
create policy org_update on organizations for update using (is_org_admin(id)) with check (is_org_admin(id));

alter table organization_members enable row level security;
create policy members_select on organization_members for select using (is_member(organization_id));
create policy members_admin_write on organization_members for all using (is_org_admin(organization_id)) with check (is_org_admin(organization_id));

alter table profiles enable row level security;
create policy profiles_self_select on profiles for select using (id = auth.uid());
create policy profiles_self_update on profiles for update using (id = auth.uid()) with check (id = auth.uid());
-- Empêche un utilisateur de s'attribuer is_platform_admin
revoke update (is_platform_admin) on profiles from authenticated, anon;

alter table subscriptions enable row level security;
create policy subs_select on subscriptions for select using (is_member(organization_id)); -- écriture : service role (webhook Stripe) uniquement

alter table plans enable row level security;
create policy plans_read on plans for select using (true);

alter table audit_logs enable row level security;
create policy audit_select on audit_logs for select using (organization_id is not null and is_org_admin(organization_id));
create policy audit_insert on audit_logs for insert with check (organization_id is null or is_member(organization_id));

alter table invoice_counters enable row level security; -- aucun accès direct

-- Une facture émise est immuable (hors paiement/statut via fonctions dédiées)
create or replace function protect_issued_invoice() returns trigger language plpgsql as $$
begin
  if old.status <> 'brouillon' and (
      new.client_id <> old.client_id or new.number is distinct from old.number or
      new.total_ht <> old.total_ht or new.total_vat <> old.total_vat or new.total_ttc <> old.total_ttc or
      new.issue_date is distinct from old.issue_date) then
    raise exception 'Facture émise non modifiable : émettre un avoir.';
  end if;
  return new;
end $$;
create trigger trg_protect_issued before update on invoices for each row execute function protect_issued_invoice();

create or replace function forbid_delete() returns trigger language plpgsql as $$
begin raise exception 'Suppression interdite sur %', tg_table_name; end $$;
create trigger trg_no_delete_invoices before delete on invoices for each row execute function forbid_delete();
create trigger trg_no_delete_payments before delete on payments for each row execute function forbid_delete();
