import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        nuit: { DEFAULT: "#0B1F3A", 700: "#12294A", 500: "#25406B" },
        electrique: { DEFAULT: "#1F6BFF", 600: "#1859D6", 50: "#EAF1FF" },
        fond: "#F4F6FA",
      },
      fontFamily: { sans: ["var(--font-sans)", "system-ui", "sans-serif"] },
      borderRadius: { carte: "10px" },
    },
  },
  plugins: [],
};
export default config;
