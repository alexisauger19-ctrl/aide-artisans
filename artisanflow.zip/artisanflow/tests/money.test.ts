import { describe, it, expect } from "vitest";
import { computeTotals, remainingBalance, isOverdue, parseEuroToCents } from "@/lib/money";

describe("computeTotals", () => {
  it("calcule HT, TVA, TTC", () => {
    const t = computeTotals([{ quantity: 2, unitPriceCents: 10000, vatRate: 20 }]);
    expect(t).toMatchObject({ totalHt: 20000, totalVat: 4000, totalTtc: 24000 });
  });
  it("gère plusieurs taux", () => {
    const t = computeTotals([
      { quantity: 1, unitPriceCents: 10000, vatRate: 10 },
      { quantity: 1, unitPriceCents: 5000, vatRate: 20 },
    ]);
    expect(t.totalVat).toBe(1000 + 1000);
    expect(Object.keys(t.vatByRate)).toHaveLength(2);
  });
  it("applique la remise et arrondit au centime", () => {
    const t = computeTotals([{ quantity: 3, unitPriceCents: 3333, discountPercent: 10, vatRate: 5.5 }]);
    expect(t.totalHt).toBe(8999);
    expect(t.totalVat).toBe(495);
  });
  it("accepte un taux 0 (franchise en base)", () => {
    expect(computeTotals([{ quantity: 1, unitPriceCents: 1000, vatRate: 0 }]).totalTtc).toBe(1000);
  });
});

describe("paiements", () => {
  it("calcule le solde restant avec paiements partiels", () => {
    expect(remainingBalance(12000, [5000, 2500])).toBe(4500);
  });
  it("détecte une facture en retard", () => {
    const today = new Date("2026-10-26T10:00:00");
    expect(isOverdue("emise", "2026-10-25", today)).toBe(true);
    expect(isOverdue("emise", "2026-10-26", today)).toBe(false);
    expect(isOverdue("payee", "2026-01-01", today)).toBe(false);
  });
  it("parse les montants français", () => {
    expect(parseEuroToCents("12,50")).toBe(1250);
    expect(() => parseEuroToCents("abc")).toThrow();
  });
});
