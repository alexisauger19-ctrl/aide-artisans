# Feuille de route (ce qui reste à construire)

Statut : ✅ fait · 🟡 partiel · ⬜ à faire

| Étape | Statut | Détail |
|---|---|---|
| Schéma, RLS, fonctions SQL | ✅ | À tester sur une vraie base (tests RLS multi-entreprises) |
| Auth, middleware, espace de travail | 🟡 | Manque : reset mot de passe, profil, logo, suppression de compte, invitations d'équipe |
| Clients | 🟡 | Manque : modification, archivage UI, fiche client, import/export CSV |
| Devis | ⬜ | Éditeur de lignes, statuts, versions, duplication, bouton « Transformer en facture » (fonction SQL prête) |
| Factures / paiements | 🟡 | Fonctions SQL prêtes ; manque UI d'émission, formulaire de paiement, avoirs |
| PDF + e-mails | ⬜ | Génération serveur (ex. @react-pdf/renderer), envoi via Resend/Postmark avec prévisualisation |
| Assistant IA | 🟡 | Route serveur prête ; manque UI de chat, contexte données, quotas, confirmation avant action |
| Automatisations | ⬜ | Cron serveur + `automation_rules`/`automation_executions` (tables prêtes) |
| Agenda | ⬜ | Vues jour/semaine/mois, fuseau Europe/Paris |
| Documents | ⬜ | Bucket Supabase Storage privé, URLs signées, validation type/taille |
| Abonnements Stripe | 🟡 | Webhook de base ; manque Checkout, portail client, mapping prix → plan, limites appliquées partout |
| Site vitrine | 🟡 | Accueil + tarifs ; manque FAQ, contact, pages légales (contenu à faire valider) |
| Admin plateforme | ⬜ | Espace réservé via `is_platform_admin` (service role uniquement), audit |
| Tests | 🟡 | Calculs OK ; manque RLS, concurrence, webhooks, permissions |
| Conformité | ⬜ | Revue juridique/comptable, RGPD (export/suppression), facturation électronique |
