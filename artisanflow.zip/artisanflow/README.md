# ArtisanFlow

SaaS d'assistance administrative pour artisans du bâtiment (clients, devis, factures, paiements, relances, IA).
Stack : Next.js 14 (App Router, TypeScript), Tailwind CSS, Supabase (PostgreSQL + Auth + RLS), Stripe, API IA côté serveur.

> **État : fondation (MVP technique), pas un produit fini.** Voir `ROADMAP.md` pour ce qui reste à faire.
> Aucune conformité RGPD, fiscale ou facturation électronique n'est revendiquée : revue juridique et comptable requise avant commercialisation.

## Installation

```bash
npm install
cp .env.example .env.local     # puis renseigner les variables
npm run dev                    # http://localhost:3000
npm test                       # tests unitaires (calculs, TVA, soldes, retards)
```

## Base de données (Supabase)

1. Créer un projet sur supabase.com.
2. Dans *SQL Editor*, exécuter dans l'ordre `supabase/migrations/0001_schema.sql`, `0002_rls.sql`, `0003_functions.sql`
   (ou `supabase db push` avec la CLI Supabase).
3. *Authentication > Providers* : activer e-mail + confirmation d'adresse. Renseigner l'URL du site dans *URL Configuration*.
4. Copier URL, clé `anon` et clé `service_role` dans `.env.local`.

## Ce qui fonctionne

- Inscription / connexion / déconnexion, routes privées protégées (middleware + RLS).
- Création d'entreprise (espace de travail) avec membre administrateur et essai de 14 jours.
- Clients : création, liste, recherche. Dashboard calculé sur les données réelles (état vide inclus).
- Base de données complète : 20 tables, contraintes, index, RLS, interdiction de supprimer factures/paiements,
  facture émise immuable, numérotation séquentielle (`issue_invoice`), paiements transactionnels (`record_payment`),
  devis → facture (`quote_to_invoice`).
- Calculs HT/TVA/TTC en centimes, TVA par taux configurable, soldes, retards (testés).
- `/api/ia` : appel serveur avec clé en variable d'environnement ; réponse 503 explicite si non configuré.
- `/api/stripe/webhook` : vérification de signature ; 503 si non configuré.

## Intégrations nécessitant des identifiants

| Service | Variables | Statut |
|---|---|---|
| Supabase | `NEXT_PUBLIC_SUPABASE_*`, `SUPABASE_SERVICE_ROLE_KEY` | requis |
| Stripe | `STRIPE_*` | non configuré par défaut |
| IA (Anthropic) | `ANTHROPIC_API_KEY` | non configuré par défaut |
| E-mails (Resend/Postmark) | `EMAIL_API_KEY`, `EMAIL_FROM` | à brancher |

## Déploiement

Vercel (frontend) + Supabase (DB/Auth/Storage). Ajouter les variables d'environnement dans Vercel,
puis configurer le webhook Stripe vers `https://VOTRE_DOMAINE/api/stripe/webhook`.
Les tâches planifiées (relances, factures en retard) se feront via Vercel Cron appelant une route protégée par `CRON_SECRET`.

## Tests exécutés

`npm test` : voir résultat dans la conversation. Les tests d'isolation RLS, de concurrence de numérotation et des webhooks
nécessitent une base de test et sont listés dans `ROADMAP.md`.
