import Link from "next/link";
export default function SiteHeader() {
  return (
    <header className="bg-nuit text-white">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
        <Link href="/" className="text-lg font-bold">ArtisanFlow</Link>
        <nav className="flex items-center gap-5 text-sm">
          <Link href="/tarifs" className="hover:underline">Tarifs</Link>
          <Link href="/connexion" className="hover:underline">Connexion</Link>
          <Link href="/inscription" className="btn">Essayer gratuitement</Link>
        </nav>
      </div>
    </header>
  );
}
