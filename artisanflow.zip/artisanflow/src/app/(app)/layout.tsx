import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentOrg } from "@/lib/supabase/server";
import { signOut } from "../actions";

const nav = [["/dashboard", "Tableau de bord"], ["/clients", "Clients"], ["/devis", "Devis"], ["/factures", "Factures"]];

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const ctx = await getCurrentOrg();
  if (!ctx) redirect("/connexion");
  return (
    <div className="min-h-screen md:flex">
      <aside className="bg-nuit text-white md:fixed md:inset-y-0 md:w-56">
        <div className="flex items-center justify-between px-4 py-4 md:block">
          <span className="text-lg font-bold">ArtisanFlow</span>
        </div>
        <nav className="flex gap-1 overflow-x-auto px-2 pb-2 md:block md:space-y-1">
          {nav.map(([href, label]) => (
            <Link key={href} href={href} className="block whitespace-nowrap rounded-lg px-3 py-2 text-sm hover:bg-nuit-700">{label}</Link>
          ))}
        </nav>
      </aside>
      <div className="flex-1 md:ml-56">
        <header className="flex items-center justify-between border-b border-slate-200 bg-white px-5 py-3">
          <span className="text-sm text-slate-600">{ctx.name ?? "Mon entreprise"}</span>
          <form action={signOut}><button className="btn-sec">Déconnexion</button></form>
        </header>
        <main className="p-5">{children}</main>
      </div>
    </div>
  );
}
