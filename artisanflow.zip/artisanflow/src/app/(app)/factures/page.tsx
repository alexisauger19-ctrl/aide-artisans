import { supabaseServer } from "@/lib/supabase/server";
import { formatEuro } from "@/lib/money";
export const metadata = { title: "Factures" };

export default async function Page() {
  const { data } = await supabaseServer().from("invoices").select("id,number,status,total_ttc,clients(name)").order("created_at", { ascending: false }).limit(100);
  return (
    <div>
      <h1 className="text-2xl font-bold">Factures</h1>
      <p className="mt-1 text-sm text-slate-600">Liste fonctionnelle. L’éditeur de lignes et l’export PDF sont la prochaine étape (voir ROADMAP.md).</p>
      <div className="carte mt-4 overflow-x-auto !p-0">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-slate-200 text-slate-500"><tr><th className="p-3">Numéro</th><th>Client</th><th>Statut</th><th>Total TTC</th></tr></thead>
          <tbody>
            {(data ?? []).map((r: any) => (
              <tr key={r.id} className="border-b border-slate-100"><td className="p-3">{r.number ?? "Brouillon"}</td><td>{r.clients?.name}</td><td>{r.status}</td><td>{formatEuro(r.total_ttc)}</td></tr>
            ))}
            {!data?.length && <tr><td colSpan={4} className="p-6 text-center text-slate-500">Rien ici pour le moment.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
