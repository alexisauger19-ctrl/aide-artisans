import Link from "next/link";
import { supabaseServer, getCurrentOrg } from "@/lib/supabase/server";
import { formatEuro, isOverdue } from "@/lib/money";

export const metadata = { title: "Tableau de bord" };

export default async function Dashboard() {
  const ctx = await getCurrentOrg();
  const sb = supabaseServer();
  // RLS garantit que seules les données de l'entreprise de l'utilisateur sont retournées.
  const [{ data: invoices }, { data: quotes }, { count: clientCount }] = await Promise.all([
    sb.from("invoices").select("status,total_ttc,paid_cents,due_date,issue_date"),
    sb.from("quotes").select("status,total_ttc"),
    sb.from("clients").select("id", { count: "exact", head: true }).is("archived_at", null),
  ]);
  const inv = invoices ?? [], qts = quotes ?? [];
  const issued = inv.filter((i) => i.status !== "brouillon" && i.status !== "annulee");
  const stats = [
    ["Facturé", formatEuro(issued.reduce((a, i) => a + i.total_ttc, 0))],
    ["Devis en attente", formatEuro(qts.filter((q) => q.status === "envoye").reduce((a, q) => a + q.total_ttc, 0))],
    ["Impayés", formatEuro(issued.reduce((a, i) => a + (i.total_ttc - i.paid_cents), 0))],
    ["Factures en retard", String(issued.filter((i) => isOverdue(i.status, i.due_date)).length)],
    ["Clients", String(clientCount ?? 0)],
    ["Devis sans réponse", String(qts.filter((q) => q.status === "envoye").length)],
  ];
  const empty = (clientCount ?? 0) === 0 && inv.length === 0 && qts.length === 0;

  return (
    <div>
      <h1 className="text-2xl font-bold">Bonjour{ctx?.name ? `, ${ctx.name}` : ""}</h1>
      {empty && (
        <div className="carte mt-6 text-center">
          <p className="font-semibold">Votre espace est prêt.</p>
          <p className="mt-1 text-sm text-slate-600">Commencez par ajouter votre premier client.</p>
          <Link href="/clients/nouveau" className="btn mt-4">Ajouter un client</Link>
        </div>
      )}
      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {stats.map(([label, value]) => (
          <div key={label} className="carte"><p className="text-sm text-slate-500">{label}</p><p className="mt-1 text-2xl font-bold">{value}</p></div>
        ))}
      </div>
    </div>
  );
}
