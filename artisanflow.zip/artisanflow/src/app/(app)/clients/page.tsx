import Link from "next/link";
import { supabaseServer } from "@/lib/supabase/server";
export const metadata = { title: "Clients" };

export default async function Clients({ searchParams }: { searchParams: { q?: string } }) {
  const sb = supabaseServer();
  let query = sb.from("clients").select("id,name,kind,email,phone,city").is("archived_at", null).order("name").limit(200);
  const q = searchParams.q?.replace(/[%,()]/g, "").trim();
  if (q) query = query.or(`name.ilike.%${q}%,email.ilike.%${q}%,phone.ilike.%${q}%`);
  const { data: clients } = await query;
  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Clients</h1>
        <Link href="/clients/nouveau" className="btn">Ajouter un client</Link>
      </div>
      <form className="mt-4"><input name="q" defaultValue={q} placeholder="Rechercher par nom, e-mail ou téléphone" className="champ max-w-md" aria-label="Rechercher" /></form>
      <div className="carte mt-4 overflow-x-auto !p-0">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-slate-200 text-slate-500"><tr><th className="p-3">Nom</th><th>Type</th><th>E-mail</th><th>Téléphone</th><th>Ville</th></tr></thead>
          <tbody>
            {(clients ?? []).map((c) => (
              <tr key={c.id} className="border-b border-slate-100"><td className="p-3 font-medium">{c.name}</td><td>{c.kind}</td><td>{c.email}</td><td>{c.phone}</td><td>{c.city}</td></tr>
            ))}
            {!clients?.length && <tr><td colSpan={5} className="p-6 text-center text-slate-500">Aucun client pour le moment.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
