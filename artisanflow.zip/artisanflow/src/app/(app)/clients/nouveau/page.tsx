"use client";
import { useFormState } from "react-dom";
import { createClientAction } from "../../../actions";

const F = ({ id, label, ...p }: { id: string; label: string } & React.InputHTMLAttributes<HTMLInputElement>) => (
  <div><label className="label" htmlFor={id}>{label}</label><input id={id} name={id} className="champ" {...p} /></div>
);

export default function NouveauClient() {
  const [state, action] = useFormState(createClientAction, null as { error?: string } | null);
  return (
    <div className="max-w-xl">
      <h1 className="text-2xl font-bold">Nouveau client</h1>
      <form action={action} className="carte mt-6 space-y-4">
        <div><label className="label" htmlFor="kind">Type</label>
          <select id="kind" name="kind" className="champ"><option value="particulier">Particulier</option><option value="professionnel">Professionnel</option></select></div>
        <F id="name" label="Nom ou raison sociale" required />
        <F id="email" label="E-mail" type="email" />
        <F id="phone" label="Téléphone" />
        <F id="address" label="Adresse" />
        <div className="grid grid-cols-2 gap-4"><F id="postal_code" label="Code postal" /><F id="city" label="Ville" /></div>
        <F id="siret" label="SIRET (professionnels)" inputMode="numeric" maxLength={14} />
        <div><label className="label" htmlFor="notes">Notes internes</label><textarea id="notes" name="notes" rows={3} className="champ" /></div>
        {state?.error && <p role="alert" className="text-sm text-red-600">{state.error}</p>}
        <button className="btn">Enregistrer le client</button>
      </form>
    </div>
  );
}
