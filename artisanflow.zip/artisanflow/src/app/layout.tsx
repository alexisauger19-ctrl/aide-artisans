import "./globals.css";
import type { Metadata } from "next";
import { Plus_Jakarta_Sans } from "next/font/google";

const sans = Plus_Jakarta_Sans({ subsets: ["latin"], variable: "--font-sans" });

export const metadata: Metadata = {
  title: { default: "ArtisanFlow — Devis, factures et relances pour artisans", template: "%s | ArtisanFlow" },
  description: "Gérez vos clients, créez vos devis et factures, suivez vos paiements et automatisez vos tâches administratives depuis un seul endroit.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr"><body className={sans.variable + " font-sans"}>{children}</body></html>
  );
}
