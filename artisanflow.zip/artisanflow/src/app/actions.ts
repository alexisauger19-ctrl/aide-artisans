"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { supabaseServer, getCurrentOrg } from "@/lib/supabase/server";

const creds = z.object({ email: z.string().email("E-mail invalide"), password: z.string().min(10, "10 caractères minimum") });

export async function signUp(_: unknown, fd: FormData) {
  const parsed = creds.extend({ company: z.string().min(2, "Nom de l’entreprise requis") }).safeParse(Object.fromEntries(fd));
  if (!parsed.success) return { error: parsed.error.issues[0].message };
  const sb = supabaseServer();
  const { data, error } = await sb.auth.signUp({
    email: parsed.data.email, password: parsed.data.password,
    options: { emailRedirectTo: `${process.env.NEXT_PUBLIC_SITE_URL}/dashboard` },
  });
  if (error) return { error: error.message };
  // Si la vérification e-mail est activée, aucune session n'existe encore : l'entreprise est créée à la première connexion.
  if (data.session) {
    const { error: e2 } = await sb.rpc("create_organization", { org_name: parsed.data.company });
    if (e2) return { error: e2.message };
    redirect("/dashboard");
  }
  return { info: "Vérifiez votre boîte e-mail pour confirmer votre adresse, puis connectez-vous." };
}

export async function signIn(_: unknown, fd: FormData) {
  const parsed = creds.pick({ email: true }).extend({ password: z.string().min(1) }).safeParse(Object.fromEntries(fd));
  if (!parsed.success) return { error: "Identifiants invalides" };
  const sb = supabaseServer();
  const { error } = await sb.auth.signInWithPassword(parsed.data);
  if (error) return { error: "E-mail ou mot de passe incorrect" };
  const ctx = await getCurrentOrg();
  if (ctx && !ctx.orgId) await sb.rpc("create_organization", { org_name: "Mon entreprise" });
  redirect("/dashboard");
}

export async function signOut() {
  await supabaseServer().auth.signOut();
  redirect("/");
}

const clientSchema = z.object({
  kind: z.enum(["particulier", "professionnel"]),
  name: z.string().min(2, "Nom requis").max(200),
  email: z.string().email("E-mail invalide").optional().or(z.literal("")),
  phone: z.string().max(30).optional(),
  address: z.string().max(300).optional(),
  postal_code: z.string().max(10).optional(),
  city: z.string().max(100).optional(),
  siret: z.string().regex(/^\d{14}$/, "SIRET : 14 chiffres").optional().or(z.literal("")),
  notes: z.string().max(5000).optional(),
});

export async function createClientAction(_: unknown, fd: FormData) {
  const ctx = await getCurrentOrg();
  if (!ctx?.orgId) return { error: "Non autorisé" };
  const parsed = clientSchema.safeParse(Object.fromEntries(fd));
  if (!parsed.success) return { error: parsed.error.issues[0].message };
  const v = Object.fromEntries(Object.entries(parsed.data).map(([k, x]) => [k, x === "" ? null : x]));
  const { error } = await supabaseServer().from("clients").insert({ ...v, organization_id: ctx.orgId });
  if (error) return { error: "Impossible d’enregistrer le client." };
  revalidatePath("/clients");
  redirect("/clients");
}
