import { NextResponse } from "next/server";
import { z } from "zod";
import { supabaseServer } from "@/lib/supabase/server";

const body = z.object({ prompt: z.string().min(3).max(4000) });

const SYSTEM = `Tu es l'assistant administratif d'un artisan français. Réponds en français.
Règles : n'invente jamais de coordonnées, de prix ni de montants ; si une information essentielle manque, pose une question.
Tu produis uniquement des BROUILLONS : aucun envoi ni émission sans confirmation explicite de l'utilisateur.`;

export async function POST(req: Request) {
  const sb = supabaseServer();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });

  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return NextResponse.json({ error: "L’assistant IA n’est pas configuré (ANTHROPIC_API_KEY manquante)." }, { status: 503 });

  const parsed = body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Requête invalide" }, { status: 400 });

  // TODO : vérifier le plan (PLAN_LIMITS) et le quota mensuel dans `subscriptions` avant l'appel.
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
    body: JSON.stringify({ model: process.env.AI_MODEL ?? "claude-sonnet-4-5", max_tokens: 1000, system: SYSTEM, messages: [{ role: "user", content: parsed.data.prompt }] }),
  });
  if (!r.ok) return NextResponse.json({ error: "Erreur du service IA, réessayez." }, { status: 502 });
  const data = await r.json();
  const text = (data.content ?? []).filter((c: any) => c.type === "text").map((c: any) => c.text).join("\n");
  return NextResponse.json({ draft: text });
}
