import { NextResponse } from "next/server";
import Stripe from "stripe";
import { createClient } from "@supabase/supabase-js";

export async function POST(req: Request) {
  const secret = process.env.STRIPE_WEBHOOK_SECRET, sk = process.env.STRIPE_SECRET_KEY;
  if (!secret || !sk) return NextResponse.json({ error: "Stripe non configuré" }, { status: 503 });

  const stripe = new Stripe(sk);
  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(await req.text(), req.headers.get("stripe-signature") ?? "", secret);
  } catch {
    return NextResponse.json({ error: "Signature invalide" }, { status: 400 });
  }

  const admin = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);
  if (event.type.startsWith("customer.subscription.")) {
    const s = event.data.object as Stripe.Subscription;
    await admin.from("subscriptions").update({
      status: s.status,
      stripe_subscription_id: s.id,
      current_period_end: new Date(s.current_period_end * 1000).toISOString(),
      // TODO : mapper s.items.data[0].price.id -> plan via la table `plans`
    }).eq("stripe_customer_id", String(s.customer));
  }
  // TODO : invoice.payment_failed, checkout.session.completed ; idempotence via event.id.
  return NextResponse.json({ received: true });
}
