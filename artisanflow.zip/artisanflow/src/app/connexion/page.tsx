"use client";
import Link from "next/link";
import { useFormState } from "react-dom";
import { signIn } from "../actions";

export default function Connexion() {
  const [state, action] = useFormState(signIn, null as { error?: string } | null);
  return (
    <main className="mx-auto mt-16 max-w-sm px-5">
      <h1 className="text-2xl font-bold">Connexion</h1>
      <form action={action} className="carte mt-6 space-y-4">
        <div><label className="label" htmlFor="email">E-mail</label><input id="email" name="email" type="email" required autoComplete="email" className="champ" /></div>
        <div><label className="label" htmlFor="password">Mot de passe</label><input id="password" name="password" type="password" required autoComplete="current-password" className="champ" /></div>
        {state?.error && <p role="alert" className="text-sm text-red-600">{state.error}</p>}
        <button className="btn w-full">Se connecter</button>
      </form>
      <p className="mt-4 text-sm">Pas encore de compte ? <Link href="/inscription" className="text-electrique underline">Créer un compte</Link></p>
    </main>
  );
}
