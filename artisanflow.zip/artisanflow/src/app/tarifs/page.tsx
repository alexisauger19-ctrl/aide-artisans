import type { Metadata } from "next";
import Link from "next/link";
import SiteHeader from "@/components/SiteHeader";
import { PLAN_DISPLAY } from "@/lib/plans";
export const metadata: Metadata = { title: "Tarifs", description: "Trois formules mensuelles : Starter, Pro et Business." };

export default function Tarifs() {
  return (
    <>
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-5 py-14">
        <h1 className="text-3xl font-extrabold">Choisissez votre formule</h1>
        <p className="mt-2 text-slate-600">Sans engagement. Prix TTC/HT et essai gratuit à confirmer dans la configuration Stripe.</p>
        <div className="mt-8 grid gap-4 md:grid-cols-3">
          {PLAN_DISPLAY.map((p) => (
            <div key={p.code} className="carte flex flex-col">
              <h2 className="font-semibold">{p.name}</h2>
              <p className="mt-1 text-3xl font-extrabold">{p.price} €<span className="text-sm font-normal text-slate-500"> / mois</span></p>
              <ul className="mt-4 flex-1 space-y-1 text-sm text-slate-600">{p.items.map((i) => <li key={i}>{i}</li>)}</ul>
              <Link href="/inscription" className="btn mt-6">Commencer l’essai</Link>
            </div>
          ))}
        </div>
      </main>
    </>
  );
}
