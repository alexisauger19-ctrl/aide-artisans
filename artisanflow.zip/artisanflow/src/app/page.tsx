import Link from "next/link";
import SiteHeader from "@/components/SiteHeader";
import { PLAN_DISPLAY } from "@/lib/plans";

const features = [
  ["Clients", "Fiches clients, historique des devis et factures, import CSV."],
  ["Devis", "Lignes, remises, TVA configurable, versions et transformation en facture."],
  ["Factures", "Numérotation séquentielle, acomptes, paiements partiels, avoirs."],
  ["Relances", "Messages prévisualisables et modifiables avant tout envoi."],
  ["Assistant IA", "Rédige vos brouillons ; chaque montant reste validé par vous."],
  ["Agenda", "Rendez-vous clients et rappels configurables."],
];

export default function Home() {
  return (
    <>
      <SiteHeader />
      <main>
        <section className="bg-nuit pb-20 pt-14 text-white">
          <div className="mx-auto max-w-6xl px-5">
            <h1 className="max-w-3xl text-4xl font-extrabold leading-tight md:text-5xl">
              Moins de paperasse, plus de chantiers.
            </h1>
            <p className="mt-5 max-w-2xl text-lg text-blue-100">
              Gérez vos clients, créez vos devis et factures, suivez vos paiements et automatisez vos tâches administratives depuis un seul endroit.
            </p>
            <Link href="/inscription" className="btn mt-8 !px-6 !py-3 text-base">Essayer gratuitement</Link>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-5 py-16">
          <h2 className="text-2xl font-bold">Ce que vous pouvez faire</h2>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {features.map(([t, d]) => (
              <div key={t} className="carte"><h3 className="font-semibold">{t}</h3><p className="mt-2 text-sm text-slate-600">{d}</p></div>
            ))}
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-5 pb-16">
          <h2 className="text-2xl font-bold">Tarifs</h2>
          <div className="mt-6 grid gap-4 md:grid-cols-3">
            {PLAN_DISPLAY.map((p) => (
              <div key={p.code} className="carte">
                <h3 className="font-semibold">{p.name}</h3>
                <p className="mt-1 text-3xl font-extrabold">{p.price} €<span className="text-sm font-normal text-slate-500"> / mois</span></p>
                <ul className="mt-4 space-y-1 text-sm text-slate-600">{p.items.map((i) => <li key={i}>{i}</li>)}</ul>
              </div>
            ))}
          </div>
        </section>
      </main>
      <footer className="border-t border-slate-200 py-8 text-center text-sm text-slate-500">
        © ArtisanFlow — Mentions légales, CGU et politique de confidentialité à compléter avant mise en production.
      </footer>
    </>
  );
}
