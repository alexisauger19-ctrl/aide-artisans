"use client";
import Link from "next/link";
import { useFormState } from "react-dom";
import { signUp } from "../actions";

export default function Inscription() {
  const [state, action] = useFormState(signUp, null as { error?: string; info?: string } | null);
  return (
    <main className="mx-auto mt-16 max-w-sm px-5">
      <h1 className="text-2xl font-bold">Créer votre compte</h1>
      <form action={action} className="carte mt-6 space-y-4">
        <div><label className="label" htmlFor="company">Nom de l’entreprise</label><input id="company" name="company" required className="champ" /></div>
        <div><label className="label" htmlFor="email">E-mail</label><input id="email" name="email" type="email" required autoComplete="email" className="champ" /></div>
        <div><label className="label" htmlFor="password">Mot de passe (10 caractères min.)</label><input id="password" name="password" type="password" minLength={10} required autoComplete="new-password" className="champ" /></div>
        {state?.error && <p role="alert" className="text-sm text-red-600">{state.error}</p>}
        {state?.info && <p className="text-sm text-green-700">{state.info}</p>}
        <button className="btn w-full">Essayer gratuitement</button>
      </form>
      <p className="mt-4 text-sm">Déjà inscrit ? <Link href="/connexion" className="text-electrique underline">Se connecter</Link></p>
    </main>
  );
}
