export type PlanCode = "starter" | "pro" | "business";
export const PLAN_LIMITS: Record<PlanCode, { ia: boolean; relances: boolean; agenda: boolean; automations: boolean; maxMembers: number }> = {
  starter: { ia: false, relances: false, agenda: false, automations: false, maxMembers: 1 },
  pro: { ia: true, relances: true, agenda: true, automations: true, maxMembers: 1 },
  business: { ia: true, relances: true, agenda: true, automations: true, maxMembers: 10 },
};
// Prix d'affichage : la source de vérité reste la table `plans` et Stripe.
export const PLAN_DISPLAY = [
  { code: "starter", name: "Starter", price: 19, items: ["Gestion des clients", "Devis", "Factures", "Export PDF", "Tableau de bord de base"] },
  { code: "pro", name: "Pro", price: 39, items: ["Tout Starter", "Assistant IA (quota mensuel)", "Relances par e-mail", "Agenda", "Automatisations de base", "Statistiques avancées"] },
  { code: "business", name: "Business", price: 79, items: ["Tout Pro", "Plusieurs membres", "Quotas IA supérieurs", "Autorisations avancées", "Exports supplémentaires"] },
] as const;
