// Tous les montants sont en centimes (entiers) pour éviter les erreurs de virgule flottante.
export type LineInput = {
  quantity: number;
  unitPriceCents: number;
  discountPercent?: number;
  vatRate: number; // en %, configurable : jamais de taux imposé par défaut
};

export type Totals = {
  totalHt: number;
  totalVat: number;
  totalTtc: number;
  vatByRate: Record<string, { baseHt: number; vat: number }>;
};

export function lineNetHt(l: LineInput): number {
  const gross = l.quantity * l.unitPriceCents;
  return Math.round(gross * (1 - (l.discountPercent ?? 0) / 100));
}

/** La TVA est calculée par taux sur la base totale (et non ligne par ligne), puis arrondie une fois. */
export function computeTotals(lines: LineInput[]): Totals {
  const vatByRate: Totals["vatByRate"] = {};
  let totalHt = 0;
  for (const l of lines) {
    const net = lineNetHt(l);
    totalHt += net;
    const key = String(l.vatRate);
    vatByRate[key] ??= { baseHt: 0, vat: 0 };
    vatByRate[key].baseHt += net;
  }
  let totalVat = 0;
  for (const [rate, group] of Object.entries(vatByRate)) {
    group.vat = Math.round((group.baseHt * Number(rate)) / 100);
    totalVat += group.vat;
  }
  return { totalHt, totalVat, totalTtc: totalHt + totalVat, vatByRate };
}

export function remainingBalance(totalTtc: number, payments: number[]): number {
  return totalTtc - payments.reduce((a, b) => a + b, 0);
}

export function isOverdue(status: string, dueDate: string | null, today = new Date()): boolean {
  if (!dueDate || !["emise", "partiellement_payee"].includes(status)) return false;
  return new Date(dueDate + "T23:59:59") < today;
}

export const formatEuro = (cents: number) =>
  new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR" }).format(cents / 100);

export const formatDate = (d: string | Date) =>
  new Intl.DateTimeFormat("fr-FR").format(typeof d === "string" ? new Date(d) : d);

/** Convertit une saisie utilisateur "12,50" en centimes. */
export function parseEuroToCents(input: string): number {
  const n = Number(input.replace(/\s/g, "").replace(",", "."));
  if (!Number.isFinite(n) || n < 0) throw new Error("Montant invalide");
  return Math.round(n * 100);
}
