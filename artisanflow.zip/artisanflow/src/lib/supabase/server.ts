import { createServerClient, type CookieOptions } from "@supabase/ssr";
import { cookies } from "next/headers";

export function supabaseServer() {
  const store = cookies();
  return createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, {
    cookies: {
      getAll: () => store.getAll(),
      setAll: (list: { name: string; value: string; options: CookieOptions }[]) => {
        try { list.forEach(({ name, value, options }) => store.set(name, value, options)); } catch { /* Server Component */ }
      },
    },
  });
}

/** Retourne l'entreprise active de l'utilisateur connecté (via RLS). */
export async function getCurrentOrg() {
  const sb = supabaseServer();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return null;
  const { data } = await sb.from("organization_members").select("organization_id, role, organizations(name)").eq("user_id", user.id).limit(1).maybeSingle();
  if (!data) return { user, orgId: null as string | null, role: null, name: null };
  const org = data.organizations as unknown as { name: string } | null;
  return { user, orgId: data.organization_id as string, role: data.role as string, name: org?.name ?? "" };
}
